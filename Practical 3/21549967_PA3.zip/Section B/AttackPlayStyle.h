#pragma once


#include "PlayStyle.h"

class AttackPlayStyle : public PlayStyle {
public:
    AttackPlayStyle();
    string attack();
};
