#pragma once


#include "PlayStyle.h"

class RunPlayStyle : public PlayStyle {
public:
    RunPlayStyle();
    string attack();
};
