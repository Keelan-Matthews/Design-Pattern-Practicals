#pragma once


#include "PlayStyle.h"

class PhysicalAttackPlayStyle : public PlayStyle {
public:
    PhysicalAttackPlayStyle();
    string attack();
};
