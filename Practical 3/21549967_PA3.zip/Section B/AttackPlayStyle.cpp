#include "AttackPlayStyle.h"

string AttackPlayStyle::attack() {
    return " is attacking the opposing Pokemon";
}

AttackPlayStyle::AttackPlayStyle() {
    this->name = "Attack";
}
