#include "PhysicalAttackPlayStyle.h"

string PhysicalAttackPlayStyle::attack() {
    return " is using physical ability to attack";
}

PhysicalAttackPlayStyle::PhysicalAttackPlayStyle() {
    this->name = "Physical Attack";
}
